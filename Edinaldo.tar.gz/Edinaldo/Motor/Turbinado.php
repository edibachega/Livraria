<?php
namespace POO\Motor;

use POO\Motor\Motor;

/**
 * Description of Turbinado
 *
 * @author aluno
 */
class Turbinado extends Motor
{
    //put your code here
}
