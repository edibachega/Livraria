<?php

namespace POO\Motor;

/**
 *
 * @author aluno
 */
interface InterfaceMotor 
{
    public function acelerar($valor = 0);
}
