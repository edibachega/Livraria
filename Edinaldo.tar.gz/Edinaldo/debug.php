<?php

$nome = "Edir";
$idade = 12;

function teste($pessoa)
{
    echo "A idade é $pessoa";
}


teste($idade);